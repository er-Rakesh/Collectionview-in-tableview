//
//  ViewController.swift
//  Expandable TableView
//
//  Created by Rakesh Kumawat on 7/31/20.
//  Copyright © 2020 Rakesh Kumawat. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

