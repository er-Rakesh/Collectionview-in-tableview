//
//  CollectionViewCell.swift
//  Expandable TableView
//
//  Created by Rakesh Kumawat on 8/8/20.
//  Copyright © 2020 Rakesh Kumawat. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
}
