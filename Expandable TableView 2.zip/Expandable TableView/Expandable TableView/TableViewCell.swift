//
//  TableViewCell.swift
//  Expandable TableView
//
//  Created by Rakesh Kumawat on 8/8/20.
//  Copyright © 2020 Rakesh Kumawat. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var collectionView: UICollectionView!
    var imageArray = [String] ()

    override func awakeFromNib() {
    super.awakeFromNib()

        self.collectionView.delegate = self
        self.collectionView.dataSource = self

        imageArray = ["image","image","image","image","image","image","image","image","image",]
// Initialization code
}
func numberOfSections(in collectionView: UICollectionView) -> Int {
return 1
}
    
func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
return 10
}
    /*
func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()

        // code for adding centered title
        headerView.backgroundColor = UIColor.white
        let headerLabel = UILabel(frame: CGRect(x: 15, y: 15, width:
            tableView.bounds.size.width, height: 28))
        headerLabel.textColor = UIColor.black
        headerLabel.text = "RECENT ITEM" //titlesList[section]
        headerLabel.textAlignment = .left
        headerView.addSubview(headerLabel)

        // code for adding button to right corner of section header
        let showHideButton: UIButton = UIButton(frame: CGRect(x:headerView.frame.size.width - 100, y:0, width:100, height:28))
        showHideButton.setTitle("Show Closed", for: .normal)
        showHideButton.backgroundColor = UIColor.blue
       // showHideButton.addTarget(self, action: #selector(btnShowHideTapped), for: .touchUpInside)

        headerView.addSubview(showHideButton)

        return headerView
    }
    
    */
func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

    if let cell: CollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as? CollectionViewCell
   // if let cell: UICollectionView = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell
                        
{
    let randomNumber = Int(arc4random_uniform(UInt32(UInt64(imageArray.count))))
cell.imageView.image = UIImage(named: imageArray[randomNumber])
return cell
}
    
return UICollectionViewCell()
}
    
    
func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
//let size = CGSize(width: 120, height: 120)
//return size
    return CGSize(width: self.collectionView.frame.size.width/2-20, height: 120)

}
    
}
